#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>	
#include <math.h>
#include <stdbool.h>
#include <assert.h>

#define ADDRESSLEN 32

int addressCount = 0;

/*Struct CacheData - Holding The Running Arguments*/
typedef struct {
	int cacheSize;
	int blockSize;
	int associativity; // 0 - FA / 1 - OneWay / 2 - TwoWay
	int setSize;
	int tagSize;
	int offsetSize;
}CacheData;

/*Struct Address - Analize each line in file*/
typedef struct {
	int tag;
	int set;
}Address;

/*Struct Cache - Holds all the addresses and the cache data*/
typedef struct {
	CacheData chd;
	Address *add;
	int *lru;
	int hits;
	int miss;
	int capacity;
}Cache;

double processCache(Cache *cache, FILE *fp);
void processAddresses(Cache *cache, char *address);
void translateAddress(Cache *cache, Address *add, char *line);
void tag(Address *add, int *address, int tagSize);
void set(Address *add, int *address, int start, int end);


int main(int argc, char* argv[])
{
	Cache cache;
	char fileName[20];
	strcpy(fileName, argv[4]);
	cache.chd.cacheSize = atoi(argv[1]);
	cache.chd.associativity = atoi(argv[2]);
	cache.chd.blockSize = atoi(argv[3]);

	FILE *fp = fopen(fileName, "r");
	assert(fp);


	printf("Miss Rate: %.1lf%% \n", processCache(&cache, fp));
	printf("Lines: %d\nHits: %d\nMiss: %d\n", addressCount, cache.hits, cache.miss);

	


	fclose(fp);

	return 0;
}

/*Reads all addresses from file and calculates miss/hits and return the miss rate*/
double processCache(Cache *cache, FILE *fp)
{
	char line[30];


	cache->capacity = (int)(cache->chd.cacheSize / cache->chd.blockSize);
	cache->add = (Address *)malloc(cache->capacity * sizeof(Address));
	assert(cache->add);

	cache->hits = 0;
	cache->miss = 0;

	cache->chd.offsetSize = (int)log2(cache->chd.blockSize);
	//Set Size according to assosiativity
	cache->chd.setSize = (cache->chd.associativity == 2) ? (int)log2(cache->capacity / 2) : (int)log2(cache->capacity);
	cache->chd.tagSize = (cache->chd.associativity == 0) ? ADDRESSLEN - cache->chd.offsetSize
		: ADDRESSLEN - cache->chd.offsetSize - cache->chd.setSize;//Tag Size according to assosiativity
	
	cache->lru = (int *)calloc(((cache->chd.associativity == 2) ? (cache->capacity / 2) : cache->capacity)
		, sizeof(int));//LRU Size Allocation
	assert(cache->lru);

	while (!feof(fp))
	{
		addressCount++;
		fscanf(fp, "%s", line);
		processAddresses(cache, line);
	}



	free(cache->lru);
	free(cache->add);
	return (((double)cache->miss / addressCount) * 100);
}

/*Process each address in the cache*/
void processAddresses(Cache *cache, char *address)
{
	Address add;
	memset(&add, 0, sizeof(Address));

	translateAddress(cache, &add, address);

	switch (cache->chd.associativity)
	{
	case 0:// FA
	{
		int hitFlag = false;

		for (int i = 0; i < cache->capacity; i++)
		{
			if (cache->add[i].tag == add.tag)
			{
				cache->hits++;
				hitFlag = true;
				cache->lru[i]++;
				break;
			}
		}
		if (!hitFlag)
		{
			cache->miss++;
			int min = cache->lru[0], index = 0;

			for (int i = 1; i < cache->capacity; i++)
			{
				if (cache->lru[i] < min)
				{
					min = cache->lru[i];
					index = i;
				}
			}
			cache->add[index].tag = add.tag;
			cache->lru[index]++;
		}
		break;
	}
	case 1: // OneWay
	{
		if (cache->add[add.set].tag == add.tag)
			cache->hits++;
		else
		{
			cache->miss++;
			cache->add[add.set].tag = add.tag;
		}

		break;
	}
	case 2:// TwoWay
	{
		if (cache->add[add.set].tag == add.tag)
		{
			cache->hits++;
			cache->lru[add.set] = 1;
		}
		else if (cache->add[add.set + 32].tag == add.tag)
		{
			cache->hits++;
			cache->lru[add.set] = 2;
		}
		else
		{
			cache->miss++;

			if (cache->lru[add.set] == 1)
				cache->add[add.set].tag = add.tag;
			else if (cache->lru[add.set] == 2)
				cache->add[add.set + 32].tag = add.tag;
			else
			{
				cache->add[add.set].tag = add.tag;
				cache->lru[add.set] = 1;
			}
		}
		break;
	}
	default:
		break;
	}	
}

/*Converts a string of digits to a number and then to binary*/
void translateAddress(Cache *cache, Address *add, char *line)
{
	int binaryAddress[32] = { 0 };
	unsigned long word = strtoll(line, NULL, 10);
	int i = 31;

	while (word > 0)
	{
		binaryAddress[i] = word % 2;
		i--;
		word = word / 2;
	}

	tag(add, binaryAddress, cache->chd.tagSize);//extract int tag from int *address
	set(add, binaryAddress, cache->chd.tagSize, cache->chd.tagSize + cache->chd.setSize);//extract int set from int *address and convert to decimal
}

/*Extract tag value from address*/
void tag(Address *add, int *binaryAddress, int tagSize)
{
	/*tag binary value from address*/
	for (int i = 0; i < tagSize; i++)
		add->tag += binaryAddress[i] * (int)pow(2, tagSize - (i + 1));
}

/*Extract set  value from address*/
void set(Address *add, int *binaryAddress, int start, int end)
{
	/*set binary value from address*/
	for (int i = start; i < end; i++)
		add->set += binaryAddress[i] * (int)pow(2, end - (i + 1));
}